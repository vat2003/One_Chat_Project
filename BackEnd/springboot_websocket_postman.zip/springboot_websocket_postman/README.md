# springboot_websocket_postman
Easy to try to implementation websocket by springboot and postman

